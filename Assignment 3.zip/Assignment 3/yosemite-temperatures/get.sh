curl -L https://www1.ncdc.noaa.gov/pub/data/uscrn/products/hourly02/README.txt

# wget https://www1.ncdc.noaa.gov/pub/data/uscrn/products/subhourly01/2011/CRNS0101-05-2011-CA_Stovepipe_Wells_1_SW.txt
# wget https://www1.ncdc.noaa.gov/pub/data/uscrn/products/subhourly01/2012/CRNS0101-05-2012-CA_Stovepipe_Wells_1_SW.txt
# wget https://www1.ncdc.noaa.gov/pub/data/uscrn/products/subhourly01/2013/CRNS0101-05-2013-CA_Stovepipe_Wells_1_SW.txt
# wget https://www1.ncdc.noaa.gov/pub/data/uscrn/products/subhourly01/2014/CRNS0101-05-2014-CA_Stovepipe_Wells_1_SW.txt
# wget https://www1.ncdc.noaa.gov/pub/data/uscrn/products/subhourly01/2015/CRNS0101-05-2015-CA_Stovepipe_Wells_1_SW.txt
# wget https://www1.ncdc.noaa.gov/pub/data/uscrn/products/subhourly01/2016/CRNS0101-05-2016-CA_Stovepipe_Wells_1_SW.txt

wget https://www1.ncdc.noaa.gov/pub/data/uscrn/products/subhourly01/2011/CRNS0101-05-2011-CA_Yosemite_Village_12_W.txt
wget https://www1.ncdc.noaa.gov/pub/data/uscrn/products/subhourly01/2012/CRNS0101-05-2012-CA_Yosemite_Village_12_W.txt
wget https://www1.ncdc.noaa.gov/pub/data/uscrn/products/subhourly01/2013/CRNS0101-05-2013-CA_Yosemite_Village_12_W.txt
wget https://www1.ncdc.noaa.gov/pub/data/uscrn/products/subhourly01/2014/CRNS0101-05-2014-CA_Yosemite_Village_12_W.txt
wget https://www1.ncdc.noaa.gov/pub/data/uscrn/products/subhourly01/2015/CRNS0101-05-2015-CA_Yosemite_Village_12_W.txt
wget https://www1.ncdc.noaa.gov/pub/data/uscrn/products/subhourly01/2016/CRNS0101-05-2016-CA_Yosemite_Village_12_W.txt
